package cpw.mods.fml.common;

public interface IFMLHandledException
{

}
