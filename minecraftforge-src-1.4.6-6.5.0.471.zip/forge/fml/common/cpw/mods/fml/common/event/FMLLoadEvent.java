package cpw.mods.fml.common.event;

public class FMLLoadEvent
{

}
