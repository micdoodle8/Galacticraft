package cpw.mods.fml.relauncher;

public class ArgsWrapper
{
    public ArgsWrapper(String[] args)
    {
        this.args=args;
    }

    public String[] args;
}
